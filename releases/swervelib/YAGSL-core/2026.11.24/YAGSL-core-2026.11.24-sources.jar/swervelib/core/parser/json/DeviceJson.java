package swervelib.core.parser.json;

import io.avaje.jsonb.Json;

import org.wpilib.math.geometry.Rotation3d;
import org.wpilib.util.Pair;
import org.wpilib.math.system.DCMotor;
import yams.core.motorcontrollers.YMotors;
import org.wpilib.units.measure.Angle;
import org.wpilib.hardware.imu.OnboardIMU;
import org.wpilib.hardware.imu.OnboardIMU.MountOrientation;
import org.wpilib.hardware.rotation.AnalogEncoder;
import org.wpilib.hardware.rotation.DutyCycleEncoder;
import swervelib.core.parser.deserializer.ReflectionsManager.AbsoluteEncoder;
import swervelib.core.parser.deserializer.ReflectionsManager.Gyro;
import swervelib.core.parser.deserializer.ReflectionsManager.VendorMotorController;
import yams.core.motorcontrollers.SmartMotorController;
import yams.core.motorcontrollers.SmartMotorControllerConfig;

import java.util.function.Supplier;

import static org.wpilib.units.Units.Rotations;

/**
 * Device JSON parsed class. Used to access the JSON data.
 */
@Json
public class DeviceJson
{

  /**
   * The device type
   */
  public String type;
  /**
   * The CAN ID or pin ID of the device.
   */
  public int    id;
  /**
   * SmartIO channel, or for a USB gyroscope the Systemcore USB port number (0 for USB0).
   */
  public int    channel = 0;
  /**
   * The CAN bus the device is on if using CAN: empty for can_s0, or the bus number, such as {@code "1"} for can_s1.
   * CTRE devices also take a CANivore's name. See {@link swervelib.core.parser.CANBuses}.
   */
  public String canbus  = "";

  /**
   * Get the DC motor from the motor type.
   *
   * @param motorType Motor type.
   * @return {@link DCMotor}
   */
  public static DCMotor getDCMotor(String motorType)
  {
    switch (motorType)
    {
      case "neo2":
      case "neo":
        return DCMotor.getNEO(1);
      case "neo550":
        return DCMotor.getNeo550(1);
      case "vortex":
        return DCMotor.getNeoVortex(1);
      case "minion":
        return DCMotor.getMinion(1);
      case "krakenx44":
        return DCMotor.getKrakenX44(1);
      case "krakenx60":
        return DCMotor.getKrakenX60(1);
      case "falcon":
      case "falcon500":
        return DCMotor.getFalcon500(1);
      case "pulsar":
        // YAMS's own model, so a Talon FXS recognizes the Pulsar.
        return YMotors.getThriftyPulsar(1);
      default:
        throw new IllegalArgumentException("Invalid motor type: " + motorType);
    }
  }

  /**
   * Get the gyro attitude supplier.
   *
   * @return {@link Pair} of the gyroscope attitude {@link Supplier} and the vendor gyroscope {@link Object}, or
   * {@code null} if the gyro type is {@code "custom"} and the user is expected to configure the gyro themselves.
   */
  public Pair<Supplier<Rotation3d>, Object> getGyro()
  {
    if ("custom".equalsIgnoreCase(type))
    {
      return null;
    }
    if (type.contains("_"))
    {
      String[] vendorData           = type.split("_");
      String   vendorType           = vendorData[0];
      String   vendorConnectionType = vendorData[1];
      switch (vendorConnectionType)
      {
        case "can":
          switch (vendorType)
          {
            case "navx3":
              return Gyro.NAVX3.getGyro(id, canbus);
            case "pigeon2":
              return Gyro.PIGEON2.getGyro(id, canbus);
            case "canandgyro":
              return Gyro.CANANDGYRO.getGyro(id, canbus);
          }
          break;
        case "usb":
          if ("navx3".equals(vendorType))
          {
            // The gyro's channel is the Systemcore USB port it's plugged into.
            return Gyro.NAVX3.getUsbGyro(channel);
          }
          break;
        case "internal":
          if ("systemcore".equals(vendorType))
          {
            // The Systemcore IMU is part of WPILib, so no vendordep reflection is needed.
            var gyro = new OnboardIMU(MountOrientation.FLAT);
            return Pair.of(gyro::getRotation3d, gyro);
          }
          break;
      }
    }
    throw new IllegalArgumentException("Invalid gyro type: " + type);
  }

  /**
   * Vendor of a device (motor controller, encoder, or gyroscope).
   */
  public enum VENDOR
  {
    /**
     * Cross The Road Electronics.
     */
    CTRE,
    /**
     * REV Robotics.
     */
    REV,
    /**
     * ThriftyBot.
     */
    THRIFTYBOT,
    /**
     * AndyMark.
     */
    ANDYMARK,
    /**
     * Redux Robotics.
     */
    REDUX,
    /**
     * Studica.
     */
    STUDICA,
    /**
     * Device attached to the roboRIO SmartIO port (DIO/Analog).
     */
    SMARTIO,
    /**
     * Limelight.
     */
    LIMELIGHT,
    /**
     * Vendor could not be determined.
     */
    UNKNOWN
  }

  /**
   * Get the vendor of the device.
   *
   * @param attachedType Vendor to return when the device is directly attached (not on CAN/DIO/Analog),
   *                      since the attached vendor cannot be determined from the device type string alone.
   * @return Vendor of the device.
   */
  public VENDOR getVendor(VENDOR attachedType)
  {
    if (type.contains("_"))
    {
      String[] vendorData           = type.split("_");
      String   vendorType           = vendorData[0];
      String   vendorConnectionType = vendorData[1];
      if (vendorConnectionType.equals("attached"))
      {
        // An encoder on a motor controller's data port belongs to that motor controller's vendor, so it becomes the
        // motor controller's feedback sensor. YAMS can't use a SPARK's analog input as its feedback sensor, so an
        // analog encoder on a SPARK stays UNKNOWN and the module reads it instead.
        if (attachedType == VENDOR.REV && (vendorType.equals("analog") || vendorType.equals("analog5v")))
        {
          return VENDOR.UNKNOWN;
        }
        return attachedType;
      }
      return switch (vendorType)
      {
        case "systemcore" -> VENDOR.LIMELIGHT;
        case "navx3" -> VENDOR.STUDICA;
        case "talonfx", "talonfxs", "cancoder", "pigeon2" -> VENDOR.CTRE;
        // A Spline Encoder is its own CAN device, so it stays UNKNOWN: the module reads it, and it never becomes a
        // SPARK's feedback sensor.
        case "sparkmax", "sparkflex" -> VENDOR.REV;
        case "nova" -> VENDOR.THRIFTYBOT;
        case "canandgyro" -> VENDOR.REDUX;
        case "andymarkhexbore" -> switch (vendorConnectionType)
        {
          case "dio", "analog" -> VENDOR.SMARTIO;
          case "can" -> VENDOR.ANDYMARK;
          default -> VENDOR.UNKNOWN;
        };
        case "canandmag" -> switch (vendorConnectionType)
        {
          case "dio" -> VENDOR.SMARTIO;
          case "can" -> VENDOR.REDUX;
          default -> VENDOR.UNKNOWN;
        };
        case "revthroughbore", "srxmag", "thrifty" -> switch (vendorConnectionType)
        {
          case "dio", "analog" -> VENDOR.SMARTIO;
          default -> VENDOR.UNKNOWN;
        };
        default -> VENDOR.UNKNOWN;
      };
    }
    return VENDOR.UNKNOWN;
  }

  /**
   * Get the {@link VendorMotorController} object for the device.
   *
   * @return {@link VendorMotorController} object for the device.
   */
  public VendorMotorController getMotorController()
  {
    if (type.contains("_"))
    {
      String[] vendorData           = type.split("_");
      String   vendorType           = vendorData[0];
      String   vendorConnectionType = vendorData[1];
      switch (vendorType)
      {
        case "nova":
          return VendorMotorController.NOVA;
        case "sparkmax":
          return VendorMotorController.SPARKMAX;
        case "sparkflex":
          return VendorMotorController.SPARKFLEX;
        case "talonfx":
          return VendorMotorController.TALONFX;
        case "talonfxs":
          return VendorMotorController.TALONFXS;
      }
    }
    return VendorMotorController.NONE;
  }

  /**
   * Get the Absolute Encoder Supplier and Vendor Absolute Encoder Object.
   *
   * @param angleMotorVendor     Vendor of the angle/steering/azimuth motor controller, used when the
   *                             absolute encoder is attached to the angle motor controller.
   * @param angleMotorController Angle/steering/azimuth {@link SmartMotorController}, used when the
   *                             absolute encoder is attached to the angle motor controller.
   * @param inverted             Inversion of the absolute encoder.
   * @return Pair of {@link Supplier} and Vendor Absolute Encoder {@link Object}
   */
  public Pair<Supplier<Angle>, Object> getAbsoluteEncoder(VendorMotorController angleMotorVendor,
                                                          SmartMotorController angleMotorController, boolean inverted)
  {
    String[] vendorData           = type.split("_");
    String   vendorType           = vendorData[0];
    String   vendorConnectionType = vendorData[1];
    switch (vendorConnectionType)
    {
      case "analog":
      {
        var analogEncoder = new AnalogEncoder(channel);
        analogEncoder.setInverted(inverted);
        return Pair.of(() -> Rotations.of(analogEncoder.get()), analogEncoder);
      }
      case "dio":
      {
        var dutyCycleEncoder = new DutyCycleEncoder(channel);
        dutyCycleEncoder.setInverted(inverted);
        return Pair.of(() -> Rotations.of(dutyCycleEncoder.get()), dutyCycleEncoder);
      }
      case "attached":
        if (angleMotorVendor == VendorMotorController.NOVA)
        {
          if (vendorType.equals("analog5v"))
          {
            throw new IllegalArgumentException(
                "analog5v_attached is for a SPARK MAX or SPARK Flex angle motor controller. On a Thrifty Nova, use "
                + "analog_attached.");
          }
          // The Nova decodes each data port encoder differently, so it needs the specific encoder type.
          return angleMotorVendor.getAbsoluteEncoder(vendorType, angleMotorController, inverted);
        }
        if (angleMotorVendor != VendorMotorController.SPARKMAX && angleMotorVendor != VendorMotorController.SPARKFLEX)
        {
          throw new IllegalArgumentException(
              type + " plugs into the angle motor controller's data port, which only a SPARK MAX, SPARK Flex or "
              + "Thrifty Nova angle motor controller supports. With a " + angleMotorVendor + " angle motor controller, "
              + "use a CAN absolute encoder such as cancoder_can, or one on a SystemCore SmartIO port (_dio or "
              + "_analog).");
        }
        return switch (vendorType)
        {
          case "andymarkhexbore", "canandmag", "revthroughbore", "srxmag", "dutycycle" ->
              angleMotorVendor.getAbsoluteEncoder("dutycycle", angleMotorController, inverted);
          case "analog", "analog5v" -> angleMotorVendor.getAbsoluteEncoder(vendorType, angleMotorController, inverted);
          case "thrifty" -> throw new IllegalArgumentException(
              "thrifty_attached is for a Thrifty Nova angle motor controller. With a SPARK MAX or SPARK Flex, plug the "
              + "Thrifty encoder into a SystemCore SmartIO port and use thrifty_analog.");
          default -> throw new IllegalArgumentException("Invalid attached encoder type: " + type);
        };
      case "can":
        switch (vendorType)
        {
          case "cancoder": return AbsoluteEncoder.CANCODER.getAbsoluteEncoder(id, canbus, inverted);
          case "canandmag": return AbsoluteEncoder.CANANDMAG.getAbsoluteEncoder(id, canbus, inverted);
          case "andymarkhexbore": return AbsoluteEncoder.ANDYMARK.getAbsoluteEncoder(id, canbus, inverted);
          case "splineencoder": return AbsoluteEncoder.SPLINE_ENCODER.getAbsoluteEncoder(id, canbus, inverted);
          default: throw new IllegalArgumentException("Invalid encoder type: " + vendorType);
        }
      default: throw new IllegalArgumentException("Invalid encoder connection type: " + vendorConnectionType);
    }
  }

  /**
   * Get the {@link SmartMotorController} from the {@link DeviceJson} when given the
   * {@link SmartMotorControllerConfig}.
   *
   * @param config {@link SmartMotorControllerConfig} to apply when creating {@link SmartMotorController}.
   * @return {@link SmartMotorController}
   */
  public SmartMotorController getSmartMotorController(SmartMotorControllerConfig config)
  {
    String[] subtypes            = type.split("_");
    String   motorControllerType = subtypes[0].toLowerCase();
    String   motorType           = subtypes[1].toLowerCase();
    DCMotor  motor               = getDCMotor(motorType);
    switch (motorControllerType)
    {
      case "talonfx":
        return VendorMotorController.TALONFX.getMotorController(id, canbus, config, motor);
      case "talonfxs":
        return VendorMotorController.TALONFXS.getMotorController(id, canbus, config, motor);
      case "sparkmax":
        return VendorMotorController.SPARKMAX.getMotorController(id, canbus, config, motor);
      case "sparkflex":
        return VendorMotorController.SPARKFLEX.getMotorController(id, canbus, config, motor);
      case "nova":
        return VendorMotorController.NOVA.getMotorController(id, canbus, config, motor);
      default:
        throw new IllegalArgumentException("Invalid motor controller type: " + motorControllerType);
    }
  }

}
