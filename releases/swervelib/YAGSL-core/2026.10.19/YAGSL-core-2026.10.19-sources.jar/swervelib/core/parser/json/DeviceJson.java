package swervelib.core.parser.json;

import io.avaje.jsonb.Json;

import org.wpilib.math.geometry.Rotation3d;
import org.wpilib.util.Pair;
import org.wpilib.math.system.DCMotor;
import org.wpilib.units.measure.Angle;
import org.wpilib.hardware.imu.OnboardIMU;
import org.wpilib.hardware.imu.OnboardIMU.MountOrientation;
import org.wpilib.hardware.rotation.AnalogEncoder;
import org.wpilib.hardware.rotation.DutyCycleEncoder;
import swervelib.core.parser.deserializer.ReflectionsManager.AbsoluteEncoder;
import swervelib.core.parser.deserializer.ReflectionsManager.Gyro;
import swervelib.core.parser.deserializer.ReflectionsManager.VendorMotorController;
import yams.core.motorcontrollers.SmartMotorController;
import yams.core.motorcontrollers.SmartMotorControllerConfig;

import java.util.function.Supplier;

import static org.wpilib.units.Units.Rotations;

/**
 * Device JSON parsed class. Used to access the JSON data.
 */
@Json
public class DeviceJson
{

  /**
   * The device type
   */
  public String type;
  /**
   * The CAN ID or pin ID of the device.
   */
  public int    id;
  /**
   * SmartIO Channel.
   */
  public int    channel = 0;
  /**
   * The CAN bus the device is on if using CAN: empty for can_s0, or the bus number, such as {@code "1"} for can_s1.
   * CTRE devices also take a CANivore's name. See {@link swervelib.core.parser.CANBuses}.
   */
  public String canbus  = "";

  /**
   * Get the DC motor from the motor type.
   *
   * @param motorType Motor type.
   * @return {@link DCMotor}
   */
  public static DCMotor getDCMotor(String motorType)
  {
    switch (motorType)
    {
      case "neo2":
      case "neo":
        return DCMotor.getNEO(1);
      case "neo550":
        return DCMotor.getNeo550(1);
      case "vortex":
        return DCMotor.getNeoVortex(1);
      case "minion":
        return DCMotor.getMinion(1);
      case "krakenx44":
        return DCMotor.getKrakenX44(1);
      case "krakenx60":
        return DCMotor.getKrakenX60(1);
      case "falcon":
      case "falcon500":
        return DCMotor.getFalcon500(1);
      case "pulsar":
        return new DCMotor(12, 3.1, 189, 1, 7500, 1);
      default:
        throw new IllegalArgumentException("Invalid motor type: " + motorType);
    }
  }

  /**
   * Get the gyro attitude supplier.
   *
   * @return {@link Pair} of the gyroscope attitude {@link Supplier} and the vendor gyroscope {@link Object}, or
   * {@code null} if the gyro type is {@code "custom"} and the user is expected to configure the gyro themselves.
   */
  public Pair<Supplier<Rotation3d>, Object> getGyro()
  {
    if ("custom".equalsIgnoreCase(type))
    {
      return null;
    }
    if (type.contains("_"))
    {
      String[] vendorData           = type.split("_");
      String   vendorType           = vendorData[0];
      String   vendorConnectionType = vendorData[1];
      switch (vendorConnectionType)
      {
        case "can":
          switch (vendorType)
          {
            case "navx3":
              return Gyro.NAVX3.getGyro(id, canbus);
            case "pigeon2":
              return Gyro.PIGEON2.getGyro(id, canbus);
            case "canandgyro":
              return Gyro.CANANDGYRO.getGyro(id, canbus);
          }
          break;
        case "internal":
          if ("systemcore".equals(vendorType))
          {
            // The Systemcore IMU is part of WPILib, so no vendordep reflection is needed.
            var gyro = new OnboardIMU(MountOrientation.FLAT);
            return Pair.of(gyro::getRotation3d, gyro);
          }
          break;
      }
    }
    throw new IllegalArgumentException("Invalid gyro type: " + type);
  }

  /**
   * Vendor of a device (motor controller, encoder, or gyroscope).
   */
  public enum VENDOR
  {
    /**
     * Cross The Road Electronics.
     */
    CTRE,
    /**
     * REV Robotics.
     */
    REV,
    /**
     * ThriftyBot.
     */
    THRIFTYBOT,
    /**
     * AndyMark.
     */
    ANDYMARK,
    /**
     * Redux Robotics.
     */
    REDUX,
    /**
     * Studica.
     */
    STUDICA,
    /**
     * Device attached to the roboRIO SmartIO port (DIO/Analog).
     */
    SMARTIO,
    /**
     * Limelight.
     */
    LIMELIGHT,
    /**
     * Vendor could not be determined.
     */
    UNKNOWN
  }

  /**
   * Get the vendor of the device.
   *
   * @param attachedType Vendor to return when the device is directly attached (not on CAN/DIO/Analog),
   *                      since the attached vendor cannot be determined from the device type string alone.
   * @return Vendor of the device.
   */
  public VENDOR getVendor(VENDOR attachedType)
  {
    if (type.contains("_"))
    {
      String[] vendorData           = type.split("_");
      String   vendorType           = vendorData[0];
      String   vendorConnectionType = vendorData[1];
      switch (vendorType)
      {
        case "systemcore":
          return VENDOR.LIMELIGHT;
        case "navx3":
          return VENDOR.STUDICA;
        case "talonfx":
        case "talonfxs":
        case "cancoder":
        case "pigeon2":
          return VENDOR.CTRE;
        case "sparkmax":
        case "sparkflex":
          return VENDOR.REV;
        case "revthroughbore":
          switch (vendorConnectionType)
          {
            case "attached": return attachedType;
            case "dio": return VENDOR.SMARTIO;
          }
        case "nova":
          return VENDOR.THRIFTYBOT;
        case "andymarkhexbore":
          switch (vendorConnectionType)
          {
            case "attached": return attachedType;
            case "dio":
            case "analog": return VENDOR.SMARTIO;
            case "can": return VENDOR.ANDYMARK;
          }
        case "canandgyro": return VENDOR.REDUX;
        case "canandmag":
          switch (vendorConnectionType)
          {
            case "attached": return attachedType;
            case "dio": return VENDOR.SMARTIO;
            case "can": return VENDOR.REDUX;
          }
        case "srxmag":
          switch (vendorConnectionType)
          {
            case "attached": return attachedType;
            case "analog": return VENDOR.SMARTIO;
          }
        case "thrifty":
          switch (vendorConnectionType)
          {
            case "attached": return attachedType;
            case "analog": return VENDOR.SMARTIO;
          }
      }
    }
    return VENDOR.UNKNOWN;
  }

  /**
   * Get the {@link VendorMotorController} object for the device.
   *
   * @return {@link VendorMotorController} object for the device.
   */
  public VendorMotorController getMotorController()
  {
    if (type.contains("_"))
    {
      String[] vendorData           = type.split("_");
      String   vendorType           = vendorData[0];
      String   vendorConnectionType = vendorData[1];
      switch (vendorType)
      {
        case "nova":
          return VendorMotorController.NOVA;
        case "sparkmax":
          return VendorMotorController.SPARKMAX;
        case "sparkflex":
          return VendorMotorController.SPARKFLEX;
        case "talonfx":
          return VendorMotorController.TALONFX;
        case "talonfxs":
          return VendorMotorController.TALONFXS;
      }
    }
    return VendorMotorController.NONE;
  }

  /**
   * Get the Absolute Encoder Supplier and Vendor Absolute Encoder Object.
   *
   * @param angleMotorVendor     Vendor of the angle/steering/azimuth motor controller, used when the
   *                             absolute encoder is attached to the angle motor controller.
   * @param angleMotorController Angle/steering/azimuth {@link SmartMotorController}, used when the
   *                             absolute encoder is attached to the angle motor controller.
   * @param inverted             Inversion of the absolute encoder.
   * @return Pair of {@link Supplier} and Vendor Absolute Encoder {@link Object}
   */
  public Pair<Supplier<Angle>, Object> getAbsoluteEncoder(VendorMotorController angleMotorVendor,
                                                          SmartMotorController angleMotorController, boolean inverted)
  {
    String[] vendorData           = type.split("_");
    String   vendorType           = vendorData[0];
    String   vendorConnectionType = vendorData[1];
    switch (vendorConnectionType)
    {
      case "analog":
      {
        var analogEncoder = new AnalogEncoder(channel);
        analogEncoder.setInverted(inverted);
        return Pair.of(() -> Rotations.of(analogEncoder.get()), analogEncoder);
      }
      case "dio":
      {
        var dutyCycleEncoder = new DutyCycleEncoder(channel);
        dutyCycleEncoder.setInverted(inverted);
        return Pair.of(() -> Rotations.of(dutyCycleEncoder.get()), dutyCycleEncoder);
      }
      case "attached":
        if (angleMotorVendor == VendorMotorController.NOVA)
        {
          // The Nova decodes each data port encoder differently, so it needs the specific encoder type.
          return angleMotorVendor.getAbsoluteEncoder(vendorType, angleMotorController, inverted);
        }
        switch (vendorType)
        {
          case "andymarkhexbore":
          case "canandmag":
          case "revthroughbore":
          case "srxmag":
          case "dutycycle":
            return angleMotorVendor.getAbsoluteEncoder("dutycycle", angleMotorController, inverted);
          case "analog":
            return angleMotorVendor.getAbsoluteEncoder("analog", angleMotorController, inverted);
          case "analog5v":
            return angleMotorVendor.getAbsoluteEncoder("analog5v", angleMotorController, inverted);
          default: throw new IllegalArgumentException("Invalid encoder type: " + vendorType);
        }
      case "can":
        switch (vendorType)
        {
          case "cancoder": return AbsoluteEncoder.CANCODER.getAbsoluteEncoder(id, canbus, inverted);
          case "canandmag": return AbsoluteEncoder.CANANDMAG.getAbsoluteEncoder(id, canbus, inverted);
          case "andymarkhexbore": return AbsoluteEncoder.ANDYMARK.getAbsoluteEncoder(id, canbus, inverted);
          case "splineencoder": return AbsoluteEncoder.SPLINE_ENCODER.getAbsoluteEncoder(id, canbus, inverted);
          default: throw new IllegalArgumentException("Invalid encoder type: " + vendorType);
        }
      default: throw new IllegalArgumentException("Invalid encoder connection type: " + vendorConnectionType);
    }
  }

  /**
   * Get the {@link SmartMotorController} from the {@link DeviceJson} when given the
   * {@link SmartMotorControllerConfig}.
   *
   * @param config {@link SmartMotorControllerConfig} to apply when creating {@link SmartMotorController}.
   * @return {@link SmartMotorController}
   */
  public SmartMotorController getSmartMotorController(SmartMotorControllerConfig config)
  {
    String[] subtypes            = type.split("_");
    String   motorControllerType = subtypes[0].toLowerCase();
    String   motorType           = subtypes[1].toLowerCase();
    DCMotor  motor               = getDCMotor(motorType);
    switch (motorControllerType)
    {
      case "talonfx":
        return VendorMotorController.TALONFX.getMotorController(id, canbus, config, motor);
      case "talonfxs":
        return VendorMotorController.TALONFXS.getMotorController(id, canbus, config, motor);
      case "sparkmax":
        return VendorMotorController.SPARKMAX.getMotorController(id, canbus, config, motor);
      case "sparkflex":
        return VendorMotorController.SPARKFLEX.getMotorController(id, canbus, config, motor);
      case "nova":
        return VendorMotorController.NOVA.getMotorController(id, canbus, config, motor);
      default:
        throw new IllegalArgumentException("Invalid motor controller type: " + motorControllerType);
    }
  }

}
